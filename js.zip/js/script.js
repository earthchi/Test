$('.page-scroll').on('click', function(e) {

 var tujuan = $(this).attr('href');

 var elemenTujuan = $(tujuan);

 $('html , body').animate({
  scrollTop: elemenTujuan.offset().top - 50
}, 1250 ,'easeInOutExpo');

 e.preventDefault();
});﻿

$(window).on('load', function(){



      $('.kiri').addClass('pok');

          $('.kanan').addClass('pok');
  });



$(window).scroll(function(){
  var wscroll = $(this).scrollTop();
  $('.jumbotron h1').css({
    'transform' : 'translate(0px, ' + wscroll/3 +'%)'
  });
});

$(window).scroll(function(){
  var wscroll = $(this).scrollTop();
  $('.jumbotron p').css({
    'transform' : 'translate(0px, ' + wscroll/1.2 +'%)'
  });

  if( wscroll > $('.portfolio').offset().top  - 200 ){
    $('.portfolio .thumbnail').each(function(i){

      setTimeout(function(){
          $('.thumbnail').eq(i).addClass('po');
      }, 300 * (i+1) );
    });




  }


});

    $(document).ready(function(){
      $("#artik1").expander({
        slicePoint : 30,
        expandText : 'More',
        userCollapseText : 'Less'
      });
    });